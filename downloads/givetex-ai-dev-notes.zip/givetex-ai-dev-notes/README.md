# AI と作る開発ノート（GiveTex）

GiveTex のサイトにのせている記事を、PDF にしたものです。印刷して読めます。

| ファイル | 内容 |
|---|---|
| `ai-team-app-development.pdf` | AI と分業して iPhone アプリをつくる方法（企画は人、実装は AI） |
| `ai-book-illustration-rules.pdf` | AI で本の挿絵をつくるときの5つのルール |

最新版は https://www.givetex.org/#articles にあります。


---
© GiveTex（https://www.givetex.org/）
個人の学習や、学校・勉強会の授業で、自由に読んで・動かして・書きかえて使えます。
そのまま再配布したり、売ったりするときは、先に https://www.givetex.org/contact/ から連絡してください。
